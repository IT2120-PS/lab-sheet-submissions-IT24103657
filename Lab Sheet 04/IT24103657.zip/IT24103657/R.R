setwd("C:/Users/it24103657/Desktop/IT24103657")

Import dataset
data <- read.table("DATA 4.txt", header = TRUE)

print(data)




boxplot(data$X1, main="Boxplot of Team Attendance (X1)")
boxplot(data$X2, main="Boxplot of Team Salary (X2)")
boxplot(data$X3, main="Boxplot of Years (X3)")

hist(data$X1, main="Histogram of Attendance", col="lightblue")
hist(data$X2, main="Histogram of Salary", col="lightgreen")
hist(data$X3, main="Histogram of Years", col="lightpink")

stem(data$X1)
stem(data$X2)
stem(data$X3)

mean(data$X1); median(data$X1); sd(data$X1)
mean(data$X2); median(data$X2); sd(data$X2)
mean(data$X3); median(data$X3); sd(data$X3)

quantile(data$X1, c(0.25, 0.75))
quantile(data$X2, c(0.25, 0.75))
quantile(data$X3, c(0.25, 0.75))

IQR(data$X1)
IQR(data$X2)
IQR(data$X3)

getmode <- function(v) {
  uniqv <- unique(v)
  uniqv[which.max(tabulate(match(v, uniqv)))]
}

getmode(data$X3)
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)  
  Q3 <- quantile(x, 0.75)  
  IQR <- Q3 - Q1           
  
  lower <- Q1 - 1.5 * IQR  
  upper <- Q3 + 1.5 * IQR  
  
  
  outliers <- x[x < lower | x > upper]
  return(outliers)
}


find_outliers(data$X1)
find_outliers(data$X2)
find_outliers(data$X3)